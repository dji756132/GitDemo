package com.blit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitConflitDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitConflitDemoApplication.class, args);
	}

}
