package com.blit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitConflitDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
